//
//  MyDocument.swift
//  iCloudStore
//
//  Created by Neil Smyth on 11/4/14.
//  Copyright (c) 2014 Neil Smyth. All rights reserved.
//

import UIKit

class MyDocument: UIDocument {

    var userText: String? = "Some Sample Text"

    override func contentsForType(typeName: String,
               error outError: NSErrorPointer) -> AnyObject {

        if let content = userText {

            var length =
                  content.lengthOfBytesUsingEncoding(NSUTF8StringEncoding)
            return NSData(bytes:content, length: length)

        } else {
            return NSData()
        }
    }

    override func loadFromContents(contents: AnyObject,
       ofType typeName: String, error outError: NSErrorPointer) -> Bool {

        if let userContent = contents as? NSData {
            userText = NSString(bytes: contents.bytes,
                       length: userContent.length,
                       encoding: NSUTF8StringEncoding) as? String
        }
        return true
    }

   
}
