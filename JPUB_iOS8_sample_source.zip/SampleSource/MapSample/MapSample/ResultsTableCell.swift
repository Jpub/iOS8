//
//  ResultsTableCell.swift
//  MapSample
//
//  Created by Neil Smyth on 11/8/14.
//  Copyright (c) 2014 Neil Smyth. All rights reserved.
//

import UIKit

class ResultsTableCell: UITableViewCell {

    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var phoneLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
