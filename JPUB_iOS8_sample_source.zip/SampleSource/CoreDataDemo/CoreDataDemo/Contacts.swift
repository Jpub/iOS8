//
//  Contacts.swift
//  CoreDataDemo
//
//  Created by Neil Smyth on 11/5/14.
//  Copyright (c) 2014 Neil Smyth. All rights reserved.
//

import Foundation
import CoreData

class Contacts: NSManagedObject {

    @NSManaged var address: String
    @NSManaged var name: String
    @NSManaged var phone: String

}
